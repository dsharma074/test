import logging
import os
import time
import math
import statistics
from PIL import Image
import traceback
import numpy as np
import paddlex as pdx
from paddleocr import PaddleOCR
import cv2

# Configure Logging
logging.basicConfig(
    filename="logfile.log",  # Replace with the correct log file path
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    filemode="w"
)
logger = logging.getLogger()

# Initialize PaddleX Model and OCR Engine
pdx_model = pdx.create_model(model_name="PP-LCNet_x1_0_doc_ori")
ocr_engine = PaddleOCR(use_angle_cls=True, lang='en', ocr_version='PP-OCRv4', invert=True, use_dilation=True, binarize=True, show_log=False)


def thick_font(image):
    image = cv2.bitwise_not(image)
    kernel = np.ones((1,1),np.uint8)
    image = cv2.dilate(image, kernel, iterations=1)
    image = cv2.bitwise_not(image)
    return image

def grayscale(image):
    return cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

def preprocess_image(image_path):
    # Read the image
    image = cv2.imread(image_path)

    inverted_image = cv2.bitwise_not(image)
    gray_image = grayscale(inverted_image)
    dilated_image = thick_font(gray_image)
    processed_img = Image.fromarray(dilated_image)
    processed_img.save(image_path)

def log_exception(func):
    """Decorator to log exceptions gracefully."""
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            logger.error(f"Error in function {func.__name__}: {str(e)}")
            traceback.print_exc()
            return None
    return wrapper

@log_exception
def get_orientation_from_paddle(output_file_path):
    """Get orientation of the document using PaddleX model."""
    output = pdx_model.predict(output_file_path, batch_size=1)
    if not output:
        logger.error(f"Prediction failed for {output_file_path}")
        return None
    
    rotated_img = None
    for res in output:
        try:
            # res.print(os.path.join(os.path.dirname(output_file_path), os.path.basename(output_file_path)+'.json'))
            print(res)
            orientation = float(res['label_names'][0])
            img = Image.open(output_file_path)
            rotated_img = img.rotate(orientation, expand=True)
            rotated_img = rotated_img.convert('RGB')
            rotated_img.save(output_file_path)
            logging.info(f"Image with fixed Orientation saved at: {output_file_path}")
        except Exception as e:
            logger.error(f"Error processing orientation for {output_file_path}: {str(e)}")
            traceback.print_exc()
            return None

    return rotated_img

@log_exception
def get_rotated_image(image_path, output_file_path):
    """Use OCR to determine image rotation."""
    angles = []
    img = Image.open(image_path)  # Open image
    print(f"Processing image file: {image_path}")
    result_old = ocr_engine.ocr(image_path, cls=True)  # Perform OCR
    if not result_old:
        logger.warning(f"OCR failed for {image_path}")
        return None
    if isinstance(result_old, list):
        if result_old[0] != None:
            for line in result_old[0]:
                XDiff = line[0][3][0] - line[0][0][0]
                YDiff = line[0][3][1] - line[0][0][1]
                angle = 0.0
                if XDiff != 0:
                    angle_radians = math.atan(-YDiff / XDiff)
                    angle = math.degrees(angle_radians)
                else:
                    angle = 90.0
                angles.append(angle)

    if len(angles)<1:
        logger.warning(f"No angles found for {image_path}")
        return None

    final_angle = statistics.mode(angles)
    rotated_image = img.rotate(-final_angle, expand=True)
    rotated_image.convert("RGB").save(output_file_path)
    
    logger.info(f"Angle of orientation for {image_path}: {final_angle}")
    return rotated_image

def fix_image_orientation(image_files, output_dir, preprocess_flag=False):
    """Fix image orientation for a list of image files."""
    start = time.time()

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
        logger.info(f"Created output directory: {output_dir}")

    for image_path in image_files:
        try:
            if preprocess_flag:
                preprocess_image(image_path)
            output_file_path = os.path.join(output_dir, os.path.basename(image_path))
            rotated_image = get_rotated_image(image_path, output_file_path)
            if rotated_image:
                rotated_image.save(output_file_path)
                logger.info(f"Saved rotated image: {output_file_path}")

                final_image = get_orientation_from_paddle(output_file_path)
                if final_image:
                    logger.info(f"Orientation fixed for {image_path}")
                else:
                    logger.warning(f"Failed to fix orientation for {image_path}")
            else:
                logger.warning(f"Rotation failed for {image_path}")
        except Exception as e:
            logger.error(f"Error processing image {image_path}: {str(e)}")
            traceback.print_exc()

    logger.info(f"Time taken to fix orientations: {time.time() - start:.2f} seconds")
    logger.info("-------------------------- End ---------------------------")
