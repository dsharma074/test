import concurrent
from openai import AzureOpenAI
import base64
import json
import asyncio
from openai import AzureOpenAI, AsyncAzureOpenAI
import os
import boto3
import base64
from pprint import pprint
from dateutil import parser
from typing import Dict
import time
from pathlib import Path
import ast
from word2number import w2n
import nltk
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay, precision_score, recall_score
from pydantic import BaseModel
import pandas as pd
from openai import AsyncAzureOpenAI
from tqdm import tqdm
import asyncio
from pathlib import Path
from typing import Callable, List, Union
import tempfile
import httpx
import openai
from fuzzywuzzy import fuzz
from pdf2image import convert_from_path
from datetime import date
from clients.llm import *
from utils import *
from clients.llm_client import *
print("Reflector Setup Done")

system_msg = "You are a reflective invoice extraction prompt improver."


class Reflector():

    def __init__(self, config):
        self.logger = get_logger(os.path.join(config['results']['results_path'], config['run_id'], "training.log"))
        self.config = config
        self.reflector_prompt = read_text_file(config['reflector']['reflector_prompt_path'])
        self.reflector_prompt = self.reflector_prompt.replace("document_type", self.config['document_metadata']['document_name'])
        self.model = self.config['model_choices'][self.config['reflector']['model_choice']]
        self.schema = config['reflector']['reflector_schema']

    def reflector(self, prompt: str, all_feedbacks, all_reasoning):
        feedback_str = json.dumps(all_feedbacks)
        reasoning = "\n".join(all_reasoning)
        reflect_prompt = self.reflector_prompt.replace("{{feedback}}", feedback_str)\
            .replace("{{prompt}}", prompt).replace('{{reasoning}}', reasoning)

        self.logger.info(f"Reflection Input Prompt: {reflect_prompt}")
        # No image to be passed
        response = run_chat_completion_dict(self.config['reflector']['system_msg'],\
                reflect_prompt, self.schema, None, self.model)
        return response

    def run_reflector(self, eval_results, new_prompt, gold, text_data):
        all_feedbacks = {}
        for doc, eval_ in tqdm(eval_results.items(), desc="Optimising Prompt: "):
            if 'extraction_issue' in list(eval_['mismatch_type'].values()):
                feedback = eval_['feedback']
                if 'File Name' in list(feedback.keys()):
                    feedback = feedback.pop('File Name')
                if feedback != {}:

                    for _, row in eval_.items():
                        row_feedback = row.get("feedback", {})
                        if isinstance(row_feedback, dict):
                            feedback.update(row_feedback)

                    # Remove File Name if present
                    feedback.pop("File Name", None)

                    if feedback:
                        new_prompt = self.reflector(
                            new_prompt,
                            feedback, 
                            gold, 
                            text_data
                        )["llm_output"]
        return new_prompt

    def run_reflector_single_call(self, eval_results, new_prompt):
        all_feedbacks = {}
        all_reasons = {}
        for doc, eval_ in tqdm(eval_results.items(), desc="Optimising Prompt: "):
            if 'extraction_issue' in list(eval_['mismatch_type'].values()):
                feedback = eval_['feedback']
                reasoning = eval_['reasoning']
                all_reasons['filename'] = reasoning
                for key, value in feedback.items():
                    if key in all_feedbacks.keys():
                        all_feedbacks[key] += ", ".join(value) if isinstance(value, list) else str(value)
                    else:
                        all_feedbacks[key] = str(value)
                if 'File Name' in list(feedback.keys()):
                    feedback = feedback.pop('File Name')
        self.logger.info(f"Feedbacks: {all_feedbacks}")
        if all_feedbacks != {}:
            new_prompt = self.reflector(new_prompt, all_feedbacks, all_reasons)
        return new_prompt