import os
import json
import boto3
from PIL import Image
from pdf2image import convert_from_path
from io import BytesIO
from tqdm import tqdm
import pandas as pd
import os
import json
import re
import json
from typing import List, Tuple, Dict, Any
import boto3
import botocore.exceptions
import base64
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
from Crypto.Util.Padding import unpad, pad
from botocore.config import Config
import os
# import imagehash
import io
from pathlib import Path
from typing import List, Tuple, Union
from pdf2image import convert_from_path
from PIL import Image
import logging
import ast


logger = logging.getLogger()
logger.setLevel(logging.INFO)


if __name__ == "__main__":

    file_path = '/home/ec2-user/SageMaker/CUW/pan_auto_train'
    files = [os.path.join(file_path, file) for file in os.listdir(file_path)]
    textract_output = "/home/ec2-user/SageMaker/CUW/output/ocr_output_txt"
    textract_output_bbox = "/home/ec2-user/SageMaker/CUW/output/ocr_bbox_output_txt"

    if not os.path.isdir(textract_output):
        os.mkdir(textract_output)
    if not os.path.isdir(textract_output_bbox):
        os.mkdir(textract_output_bbox)

    for file in tqdm(files, desc= "Text Extracted:"):
        try:
            filename = os.path.join(textract_output, Path(file).stem + '.txt')
            image_bytes_list = get_images(file)
            text, text_bbox = parse_detect_document_text(detect_document_text(image_bytes_list[0]))
            combined_text = " ".join(text)
            with open(str(filename), 'w') as text_file:
                text_file.write(combined_text)

            filename = os.path.join(textract_output_bbox, Path(file).stem + '.txt')
            with open(str(filename), 'w') as text_file:
                text_file.write(str(text_bbox))
        except Exception as e:
            print(file, e)