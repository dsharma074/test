import concurrent
from openai import AzureOpenAI
import base64
import json
import asyncio
from openai import AzureOpenAI, AsyncAzureOpenAI
import os
import boto3
import base64
from pprint import pprint
from dateutil import parser
from typing import Dict
import time
from pathlib import Path
import ast
from concurrent.futures import ThreadPoolExecutor, as_completed

from word2number import w2n
import nltk
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay, precision_score, recall_score
from pydantic import BaseModel
import pandas as pd
from openai import AsyncAzureOpenAI
from tqdm import tqdm
import asyncio
from pathlib import Path
from typing import Callable, List, Union
import tempfile
import httpx
import openai
from utils import *
from fuzzywuzzy import fuzz
from pdf2image import convert_from_path
from datetime import date
from clients.llm import run_chat_completion_dict, run_chat_completion_text
from clients.llm_client import InHouseLLMClient
print("Evaluator Setup Done")


class Evaluator():

    def __init__(self, config):
        self.config = config
        self.evaluator_prompt = read_text_file(config['evaluator']['evaluator_prompt_path'])
        self.model = self.config['model_choices'][self.config['evaluator']['model_choice']]

    def evaluator(self, text_data, pred, gold, accuracy_map, file):

        eval_prompt = self.evaluator_prompt.replace("{{text_data}}", str(text_data)) \
            .replace("{{pred}}", json.dumps(pred, indent=2)) \
            .replace("{{gold}}", json.dumps(gold)) \
            .replace("{{accuracy_map}}", json.dumps(accuracy_map))
        evaluator_schema = self.config['evaluator']['evaluator_schema']
        response, image = detect_document_text_with_path(file)
        response = run_chat_completion_dict(self.config['evaluator']['system_msg'], eval_prompt, evaluator_schema, image, self.model)
        try:
            return response
        except Exception as e:
            print("Error: ", e)
            return {}

    def convert_to_number(self, s):
        if type(s) == float:
            return int(s)
        if s:
            import locale
            try:
                locale.setlocale(locale.LC_NUMERIC, 'en_US.UTF-8')
                number = locale.atof(s)
                return number
            except Exception as e:
                return s
        else:
            return 0

    def get_accuracy_scores(self, pred, gold):
        accuracy_score = {}
        for key, value in pred.items():

            if key in self.config['accuracy']['partial_ratio']:
                accuracy_score[key] = 1 if fuzz.ratio(value, gold[key]) > 0.96 else 0

            if key in self.config['accuracy']['equality']:
                accuracy_score[key] = 1 if value == gold[key] else 0

            if key in self.config['accuracy']['convert_to_number']: 
                accuracy_score[key] = 1 if convert_to_number(value) == convert_to_number(gold[key]) else 0

            if key in self.config['accuracy']['date']:
                pred_date = parser.parse(str(value), dayfirst=True).date().strftime('%d-%m-%Y')
                gold[key] = parser.parse(str(gold[key]), dayfirst=True).date().strftime('%d-%m-%Y')
                accuracy_score[key] = 1 if pred_date == gold[key] else 0

        result = 1 if all(v == 1 for v in accuracy_score.values()) else 0

        accuracy_score['heuristic_doc_ext_accuracy'] = result
        return accuracy_score

    def heuristic_evaluate_accuracy(self, outputs, annotations):
        eval_accuracy = []
        for extraction in tqdm(outputs, desc="Running Accuracy Check"):
            gold = {}
            gold = annotations[annotations[self.config['document_metadata']['file_key']] == str(extraction['filename'])].iloc[0].to_dict()
            gold.pop(self.config['document_metadata']['file_key'], None)
            pred = {k: v for k,v in extraction['llm_output'].items()}
            accuracy_score = self.get_accuracy_scores(pred, gold)
            accuracy = {'filename': extraction['filename'], **accuracy_score}
            eval_accuracy.append(accuracy)
        eval_accuracy_df = pd.DataFrame(eval_accuracy)
        return eval_accuracy_df

    def _evaluate_single_extraction(self, extraction, annotations):
        file_key = self.config['document_metadata']['file_key']
        label_columns = self.config['document_metadata']['label_columns']

        gold = (
            annotations[annotations[file_key] == str(extraction['filename'])]
            .iloc[0]
            .to_dict()
        )
        gold.pop(file_key, None)

        pred = {
            k: extraction['llm_output'].get(k)
            for k in label_columns
        }
        accuracy_score = self.get_accuracy_scores(pred, gold)
        result = self.evaluator(
            extraction['input'],
            extraction['llm_output'],
            gold,
            accuracy_score,
            str(extraction['filename'])
        )

        return extraction['filename'], result

    def run_evaluator(self, outputs, annotations, max_workers=2):
        eval_results = {}
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = [
                executor.submit(
                    self._evaluate_single_extraction,
                    extraction,
                    annotations
                )
                for extraction in outputs
            ]

            for future in tqdm(
                as_completed(futures),
                total=len(futures),
                desc="Running LLM Judge (MT)"
            ):
                filename, result = future.result()
                eval_results[filename] = result

        return eval_results


    def convert_eval_to_df(self, eval_results):
        rows = []

        for filename, entry in eval_results.items():
            try:
                flat = {
                    "filename": filename,
                    "image_quality": entry.get("image_quality"),
                    "image_quality_reasoning": entry.get("image_quality_reasoning"),
                    "reasoning": entry.get("reasoning", ""),
                    "cost": entry.get("cost", 0),
                    "eval_prompt_tokens": entry.get("prompt_tokens", 0),
                    "eval_completion_tokens": entry.get("completion_tokens", 0),
                    "eval_total_tokens": entry.get("total_tokens", 0),
                }

                # ---------- mismatch_type (dict) ----------
                mismatch_dict = entry.get("mismatch_type", {}) or {}
                for k, v in mismatch_dict.items():
                    flat[f"mismatch__{k}"] = v

                # ---------- feedback (dict of lists) ----------
                feedback_dict = entry.get("feedback", {}) or {}
                for k, v in feedback_dict.items():
                    # join list feedback into readable string
                    flat[f"feedback__{k}"] = " | ".join(v) if isinstance(v, list) else v

                # ---------- document-level accuracy ----------
                flat["llm_doc_ext_accuracy"] = (
                    1 if any(v == "extraction_issue" for v in mismatch_dict.values())
                    else 0
                )

                rows.append(flat)
            except Exception as e:
                print(f'Error converting to Eval DF: {e}')

        return pd.DataFrame(rows)

