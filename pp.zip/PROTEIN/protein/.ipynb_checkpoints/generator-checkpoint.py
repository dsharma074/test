import concurrent
from openai import AzureOpenAI
import base64
import json
import boto3
import asyncio
from openai import AzureOpenAI, AsyncAzureOpenAI
import os
import base64
from botocore.config import Config
from pprint import pprint
import time
from pathlib import Path
import ast
import io
import nltk
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay, precision_score, recall_score
from pydantic import BaseModel
import pandas as pd
from openai import AsyncAzureOpenAI
from tqdm import tqdm
import asyncio
from pathlib import Path
from typing import Callable, List, Union
from typing import List, Dict, Tuple, Any
import tempfile
import httpx
import openai
from pdf2image import convert_from_path
from datetime import date
from utils import *
from clients.llm_client import *
from clients.llm import *
print("Generator Setup Done")


class Generator():

    def __init__(self, config):
        self.generation_prompt = ""
        self.logger = get_logger(os.path.join(config['results']['results_path']\
                                              , config['run_id'], "training.log"))
        document_name = config.get("document_metadata", {}).get("document_name")
        generator_path = config.get("generator", {}).get("generator_prompt_path")
        with open(generator_path, "r") as file:
            self.generation_prompt = file.read()
        self.config = config
        self.logger.info(f"Document to Prompt-Tune: {document_name}")
        self.object_prompt = self.config['generator']['objective_prompt']\
            .replace("document_name", document_name)

    def detect_document_text(self, image_bytes: bytes, region: str = "ap-south-1") -> list:
        if not isinstance(image_bytes, (bytes, bytearray)):
            raise TypeError("image_bytes must be bytes or bytearray")

        if not image_bytes:
            raise ValueError("image_bytes cannot be empty")

        # Configure boto3 retries
        my_config = Config(
            retries={
                'max_attempts': 2,
                'mode': 'standard'
            }
        )
        try:
            textract = boto3.client("textract", region_name=region, config=my_config)
            response = textract.detect_document_text(Document={"Bytes": image_bytes})
            angle = get_orientation_from_textract(response)
            new_Image = image_bytes
            if angle != 0:
                new_Image = rotate_image(image_bytes, angle)
            response = textract.detect_document_text(Document={"Bytes": new_Image})
            blocks = response.get("Blocks", [])
            return blocks

        except Exception as e:
            self.logger.error(f"Error in Textract detect_document_text: {e}", exc_info=True)
            raise

    def normalize_bboxes_relative(self, polygons, ref_polygon, eps=1e-6):
        """
        polygons: List[List[List[x, y]]]  # list of 4-point polygons
        ref_polygon: List[List[x, y]]     # 4-point polygon
        """
        # Reference bbox from polygon
        rx = [p[0] for p in ref_polygon]
        ry = [p[1] for p in ref_polygon]

        rx1, rx2 = min(rx), max(rx)
        ry1, ry2 = min(ry), max(ry)

        rw = rx2 - rx1
        rh = ry2 - ry1

        # Skip degenerate reference polygon
        if rw < eps or rh < eps:
            return None

        normalized = []

        for poly in polygons:
            norm_poly = []
            for x, y in poly:
                nx = (x - rx1) / rw
                ny = (y - ry1) / rh
                norm_poly.append([nx, ny])

            normalized.append(norm_poly)
        return normalized

    def parse_detect_document_text(self, blocks: List[Dict[str, Any]]) -> Tuple[List[str], List[list]]:
        plain_texts: List[str] = []
        detailed_texts: List[list] = []

        for block in blocks:
            if block.get("BlockType") == "LINE":  # or WORD if you prefer
                text = block.get("Text", "")
                confidence = round(block.get("Confidence", 0.0), 2)
                polygon = [
                    [round(p.get("X", 0.0), 4), round(p.get("Y", 0.0), 4)]
                    for p in block.get("Geometry", {}).get("Polygon", [])
                ]
                plain_texts.append(text)
                block_data = {'text': text, 'bbox': polygon}
                detailed_texts.append(block_data)
        detailed_texts = sorted(
                        detailed_texts,
                        key=lambda x: (min(p[1] for p in x["bbox"]), min(p[0] for p in x["bbox"])))
        return plain_texts, detailed_texts

    def get_images(self, file_path):
        file_path = Path(file_path)
        ext = file_path.suffix.lower()
        image_bytes_list = []

        if ext == ".pdf":
            pages = convert_from_path(str(file_path), dpi=200)
            for page in pages:
                buf = io.BytesIO()
                page.save(buf, format="JPEG")
                b = buf.getvalue()
                image_bytes_list.append(b)

        elif ext in [".png", ".jpg", ".jpeg", ".tiff", ".bmp", ".gif"]:
            img = Image.open(file_path)
            buf = io.BytesIO()
            fmt = "JPEG"
            # fmt = "PNG" if ext == ".png" else "JPEG"
            img.save(buf, format=fmt)
            b = buf.getvalue()
            image_bytes_list.append(b)
        return image_bytes_list

    def per_example_prompting(self, row, label_columns, text_data, image, model_choice, prompt_template, max_retries=2, retry_delay=2):
        outputs = []
        response = None
        file_key = self.config['document_metadata']['file_key']
        label = str(row[label_columns].to_dict())
        user_prompt = prompt_template.replace("{input_text}", str(text_data)).replace("{label}", label)
        with open('user_prompt.txt', 'w') as file:
            file.write(user_prompt)
        retry_count = 0
        response = {}
        system_msg = self.config['evaluator']['system_msg']
        while retry_count < max_retries:
            try:
                response = run_chat_completion_dict(system_msg, user_prompt, None, image, model_choice)
                break
            except Exception as e:
                self.logger.error("OpenAI Error: ", e)
                if hasattr(e, 'status_code') and e.status_code == 500:
                    retry_count += 1
                    self.logger.error(f"Retrying ({retry_count}/{max_retries}) after HTTP 500 error...", model_choice)
                    time.sleep(retry_delay)
                else:
                    self.logger.error("Error ", e)
        outputs.append({
            "id": row.get("id", None),
            "input": text_data,
            "filename": row.get(file_key),
            "llm_output": response})
        return outputs

    def prompt_construction(self, prompt_cot, schema):
        SCHEMA = {}
        file_key = self.config['document_metadata']['file_key']
        for key, value in schema.items():
            if key != file_key:
                SCHEMA[key] = "<value prediction>"
        SCHEMA = json.dumps(SCHEMA)
        prompt = ""
        for file_prompt in prompt_cot:
            lines = [self.object_prompt, "Schema:", SCHEMA, "Entities to be Extracted:"]
            for key, value in file_prompt.get('llm_output', {}).items():
                if key in list(schema.keys()):
                    lines.append(f"{key}:")
                    lines.append("Key Definition:")
                    lines.append(value.get('key_definitions', ''))
                    lines.append("Chain of thought Reasoning:")
                    for idx, reasoning in enumerate(value.get('reasoning', [])):
                        lines.append(f"Step {idx}: " + str(reasoning))
            prompt = "\n".join(lines)
        return prompt