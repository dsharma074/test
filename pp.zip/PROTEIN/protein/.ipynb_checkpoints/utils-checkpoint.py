import concurrent
from openai import AzureOpenAI
import base64
import json
import asyncio
from openai import AzureOpenAI, AsyncAzureOpenAI
import os
import base64
from pprint import pprint
import trp.trp2 as t2
import trp as t1
import tempfile
import httpx
import openai
from trp.t_pipeline import add_page_orientation
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from tqdm import tqdm
import time
from pathlib import Path
import ast
import nltk
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay, precision_score, recall_score
from pydantic import BaseModel
import pandas as pd
from openai import AsyncAzureOpenAI
from tqdm import tqdm
import asyncio
from pathlib import Path
from typing import Callable, List, Union
from typing import List, Dict, Tuple, Any
import tempfile
import httpx
import openai
from clients.llm import *
from clients.llm_client import *
from pdf2image import convert_from_path
from datetime import date
import logging
import os

# =======================
# Imports
# =======================
import os
import io
import time
import json
import base64
import logging
from pathlib import Path
from typing import List, Dict, Tuple, Any

import boto3
from botocore.config import Config
from PIL import Image
from pdf2image import convert_from_path
from tqdm import tqdm

import trp.trp2 as t2
import trp as t1
from trp.t_pipeline import add_page_orientation

# =======================
# Logger
# =======================
def get_logger(log_path="results/run2/training.log"):
    os.makedirs(os.path.dirname(log_path), exist_ok=True)
    logger = logging.getLogger("prompt_trainer")
    logger.setLevel(logging.INFO)

    if logger.handlers:
        return logger

    fh = logging.FileHandler(log_path)
    ch = logging.StreamHandler()

    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )

    fh.setFormatter(formatter)
    ch.setFormatter(formatter)

    logger.addHandler(fh)
    logger.addHandler(ch)
    return logger


# =======================
# Utilities
# =======================
def pil_to_bytes(image: Image.Image, fmt="JPEG") -> bytes:
    buf = io.BytesIO()
    image.save(buf, format=fmt)
    return buf.getvalue()


def normalize_angle(angle: float, snap_threshold: int = 10) -> float:
    rounded = round(angle / 90) * 90
    if abs(angle - rounded) <= snap_threshold:
        return rounded % 360
    return angle % 360

# =======================
# Image Loading
# =======================
def get_images(file_path: str) -> List[bytes]:
    file_path = Path(file_path)
    ext = file_path.suffix.lower()
    image_bytes_list = []

    if ext == ".pdf":
        pages = convert_from_path(str(file_path), dpi=200)
        for page in pages:
            image_bytes_list.append(pil_to_bytes(page))
    else:
        img = Image.open(file_path).convert("RGB")
        image_bytes_list.append(pil_to_bytes(img))

    return image_bytes_list


# =======================
# Textract
# =======================
def create_textract_client(region="ap-south-1"):
    return boto3.client(
        "textract",
        region_name=region,
        config=Config(
            retries={"max_attempts": 5, "mode": "standard"}
        ),
    )


def detect_document_text(image_bytes: bytes, textract_client) -> Dict[str, Any]:
    response = textract_client.detect_document_text(
        Document={"Bytes": image_bytes}
    )
    return response


def get_orientation_from_textract(response: dict) -> float:
    if not response:
        return 0.0

    t_document = t2.TDocumentSchema().load(response)
    t_document = add_page_orientation(t_document)
    doc = t1.Document(t2.TDocumentSchema().dump(t_document))

    raw_angle = doc.pages[0].custom.get(
        "PageOrientationBasedOnWords", 0.0
    )
    return normalize_angle(float(raw_angle))


def get_cropped_path(final_path: str) -> str:
    p = Path(final_path)
    return str(p.with_name(p.stem + "_crop" + p.suffix))


def rotate_image(image_bytes: bytes, angle: float) -> Image.Image:
    img = Image.open(io.BytesIO(image_bytes))
    if angle % 360 == 0:
        return img
    return pil_to_bytes(img.rotate(angle, expand=True).convert("RGB"))


# =======================
# OCR WITH ROTATION + PATH PROPAGATION
# =======================
def detect_document_text_with_path(
    image_path: str,
    region="ap-south-1",
):
    """
    Returns:
        blocks: Textract blocks AFTER crop
        final_path: cropped image path (rotated+cropped if applicable)
    """
    try:
        textract_client = create_textract_client(region)
    
        # ---- Load original image ----
        original_image_bytes = get_images(image_path)[0]
        # ---- First OCR (orientation) ----
        response = detect_document_text(original_image_bytes, textract_client)
        blocks, text_bbox = parse_detect_document_text(
            response.get("Blocks", [])
        )
        # ---- CROP HERE (🔥 injected) ----
        cropped_image = crop_from_ocr_bboxes(Image.open(io.BytesIO(original_image_bytes)).convert("RGB"), text_bbox)
        angle = get_orientation_from_textract(response)

        final_image_bytes = pil_to_bytes(cropped_image)
        final_path = image_path

        # ---- Rotate if needed ----
        if angle and angle > 0:
            final_image_bytes = rotate_image(final_image_bytes, angle)

        # Re-run OCR after rotation
        response = detect_document_text(
            final_image_bytes,
            textract_client
        )
        cropped_image = prepare_for_gpt(cropped_image)
        return response.get("Blocks", []), cropped_image
    except Exception as e:
        print(e)
        return None, None


# =======================
# Parse OCR Output
# =======================
def parse_detect_document_text(
    blocks: List[Dict[str, Any]]
) -> Tuple[List[str], List[Dict[str, Any]]]:

    plain_texts = []
    detailed_texts = []

    for block in blocks:
        if block.get("BlockType") == "LINE":
            text = (block.get("Text") or "").strip()
            confidence = block.get("Confidence", 0)
            text = block.get("Text", "")
            if int(confidence) < 40:
                continue
            polygon = [
                [round(p["X"], 4), round(p["Y"], 4)]
                for p in block.get("Geometry", {}).get("Polygon", [])
            ]
            plain_texts.append(text)
            detailed_texts.append({
                "text": text,
                "bbox": polygon,
                'confidence': confidence
            })

    # reading order
    detailed_texts.sort(
        key=lambda x: (
            min(p[1] for p in x["bbox"]),
            min(p[0] for p in x["bbox"]),
        )
    )
    return plain_texts, detailed_texts


def crop_from_ocr_bboxes(
    image: Image.Image,
    ocr_items: List[Dict[str, Any]],
    pad_ratio: float = 0.1,
) -> Image.Image | None:

    if not ocr_items:
        return None

    W, H = image.size

    x1min, y1min = float("inf"), float("inf")
    x2max, y2max = 0.0, 0.0

    for item in ocr_items:
        poly = item["bbox"]  # [[x,y], [x,y], [x,y], [x,y]]

        xs = [p[0] for p in poly]
        ys = [p[1] for p in poly]

        x1min = min(x1min, min(xs))
        y1min = min(y1min, min(ys))
        x2max = max(x2max, max(xs))
        y2max = max(y2max, max(ys))

    if x1min == float("inf"):
        return None

    # Padding
    pad_x = pad_ratio * W
    pad_y = pad_ratio * H

    # Normalized → pixel coords + clamp
    crop_box = (
        max(0, int(x1min * W - pad_x)),
        max(0, int(y1min * H - pad_y)),
        min(W, int(x2max * W + pad_x)),
        min(H, int(y2max * H + pad_y)),
    )

    if crop_box[2] <= crop_box[0] or crop_box[3] <= crop_box[1]:
        return None

    return image.crop(crop_box)


# =======================
# MAIN LOOP (DROP-IN)
# =======================
def run_ocr_pipeline(annotations_data, file_key):
    results_text = {}
    results_text_bbox = {}
    path_map = {}

    for _, row in tqdm(
        annotations_data.iterrows(),
        total=len(annotations_data),
        desc="Performing OCR using Textract",
    ):
        file_path = row.get(file_key)

        if pd.isna(file_path) or not os.path.exists(file_path):
            print(file_path)
            continue

        blocks, final_path = detect_document_text_with_path(file_path)
        text, text_bbox = parse_detect_document_text(blocks)

        results_text[file_path] = text
        results_text_bbox[file_path] = text_bbox
        path_map[file_path] = final_path

    annotations_data[file_key] = annotations_data[file_key].map(
        lambda x: path_map.get(x, x)
    )
    return results_text, results_text_bbox


def run_ocr_pipeline_file(row, file_key):
    if os.path.exists(row[file_key]):
        try:
            file_path = row.get(file_key)
            blocks, final_image = detect_document_text_with_path(file_path)
            text, text_bbox = parse_detect_document_text(blocks)
            return text, text_bbox, final_image
        except Exception as e:
            print(e)
            return None, None, None
    else:
        print(f"OCR Error: {row.get(file_key)}")
        return None, None, None


def run_ocr_pipeline_file_path(file_path):
    if os.path.exists(file_path):
        try:
            blocks, final_image = detect_document_text_with_path(file_path)
            text, text_bbox = parse_detect_document_text(blocks)
            return text, text_bbox, final_image
        except Exception as e:
            print(e)
            return None, None, None
    else:
        print(file_path)
        return None, None, None


def timing(func: Callable) -> Callable:
    """Decorator to measure the execution time of a function."""
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        end = time.time()
        print(f"  {func.__name__}() took {end - start:.2f} seconds")
        return result

    return wrapper


def pdf_to_image_bytes(file_path):
    ext = os.path.splitext(file_path)[1].lower()
    img_bytes_list = []
    if ext == ".pdf":
        images = convert_from_path(file_path, dpi=300)
    else:
        images = [Image.open(file_path)]
    for img in images:
        buf = BytesIO()
        img.save(buf, format="JPEG")
        img_bytes_list.append(buf.getvalue())
    return img_bytes_list


def pdf_to_image_bytes_zoomed(pdf_path, dpi=300, zoom_factor=1.5):
    images = convert_from_path(pdf_path, dpi=dpi)
    img_bytes_list = []
    for img in images:
        # Resize / zoom
        if zoom_factor != 1.0:
            img = img.resize((int(img.width * zoom_factor), int(img.height * zoom_factor)), Image.LANCZOS)
        # Save to bytes
        buf = BytesIO()
        img.save(buf, format="JPEG", quality=85)
        img_bytes_list.append(buf.getvalue())
    return img_bytes_list


def render_pdf_page_under_limit(path):
    img_bytes_list=pdf_to_image_bytes(path)
    encoded=[base64.b64encode(img_bytes_list[i]).decode("utf-8") for i in range(len(img_bytes_list))]
    return f"data:image/jpeg;base64,{encoded[0]}"


def read_text_file(file):
    with open(file, 'r') as file:
        return file.read()


def build_image_parts(image_paths: List[Union[str, Path]]) -> List[dict]:
    return [
        {
            "type": "image_url",
            "image_url": {
                "url": render_pdf_page_under_limit(path),
                "detail": "auto"
            }
        }
        for path in image_paths
    ]


def get_text_textract(text, text_bbox):
    text_files = [os.path.join(text, file) for file in os.listdir(text) if file.endswith('.txt')]
    textbbox_files = [os.path.join(text_bbox, file) for file in os.listdir(text_bbox) if file.endswith('.txt')]

    results_text = {Path(file).stem:read_text_file(file) for file in text_files}
    results_bbox_text = {Path(file).stem:read_text_file(file) for file in textbbox_files}

    return results_text, results_bbox_text


def parse_json_garbage(s):
    s = s.replace('`', '')
    s = s[next(idx for idx, c in enumerate(s) if c in "{["):]
    try:
        return json.loads(s)
    except json.JSONDecodeError as e:
        return json.loads(s[:e.pos])


def read_text_file(file):
    with open(file, 'r') as file:
        return file.read()


def _process_single_row(
    row,
    config,
    model_choice,
    system_msg,
    schema,
    user_prompt,
    max_retries,
    retry_delay
):
    key = config['document_metadata']['file_key']
    file_path = row[key]
    text, text_bbox, final_image = run_ocr_pipeline_file(row, key)
    if model_choice['ocr']:
        user_prompt = user_prompt + f"\n Input Data: {text_bbox}"

    response = None
    retry_count = 0
    while retry_count < max_retries:
        try:
            response = run_chat_completion_dict(
                system_msg,
                user_prompt,
                schema,
                final_image,
                model_choice
            )
            break
        except Exception as e:
            print("OpenAI Error:", e)
            if hasattr(e, "status_code") and e.status_code == 500:
                retry_count += 1
                print(
                    f"Retrying ({retry_count}/{max_retries}) after HTTP 500 error...",
                    model_choice
                )
                time.sleep(retry_delay)
            else:
                break

    return {
        "input": text_bbox,
        "filename": file_path,
        "llm_output": response
    }

def per_example_prompting_extraction(
    config,
    model_choice,
    system_msg,
    schema,
    user_prompt,
    annotations,
    max_retries=5,
    retry_delay=5,
    max_workers=16  # adjust based on load
):
    outputs = []

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [
            executor.submit(
                _process_single_row,
                row,
                config,
                model_choice,
                system_msg,
                schema,
                user_prompt,
                max_retries,
                retry_delay
            )
            for _, row in annotations.iterrows()
        ]

        for future in tqdm(
            as_completed(futures),
            total=len(futures),
            desc="Running Extraction (MT)"
        ):
            outputs.append(future.result())

    return outputs


def prepare_for_gpt(img):
    img = img.convert("RGB")

    max_side = max(img.size)
    if max_side < 1000:
        scale = 1200 / max_side
        img = img.resize(
            (int(img.width * scale), int(img.height * scale)),
            Image.LANCZOS
        )

    return img
    
# def per_example_prompting_extraction(config, model_choice, system_msg, schema, user_prompt, annotations, max_retries=2, retry_delay=2):
#     outputs = []
#     for idx, row in tqdm(annotations.iterrows(), desc="Running Extraction: "):
#         # if str(Path(filename).stem.replace('.','')) not in list(annotations["FILE NAME"]):
#         #     continue
#         key = config['document_metadata']['file_key']
#         file_path = row[key]
#         text, text_bbox, final_image = run_ocr_pipeline_file(row, key)
#         response = None
#         # label = str(annotations[annotations['File Name'] == filename].iloc[0].to_dict())
#         retry_count = 0
#         system_msg = system_msg + f"\n Input Data: {text_bbox}"
#         while retry_count < max_retries:
#             try:
#                 response = run_chat_completion_dict(system_msg, user_prompt, schema, final_image, model_choice)
#                 break
#             except Exception as e:
#                 print("OpenAI Error: ", e)
#                 if hasattr(e, 'status_code') and e.status_code == 500:
#                     retry_count += 1
#                     print(f"Retrying ({retry_count}/{max_retries}) after HTTP 500 error...", model_choice)
#                     time.sleep(retry_delay)
#                 else:
#                     print("Error ", e)
#         outputs.append({
#             "input": text_bbox,
#             "filename": file_path,
#             "llm_output": response})
#     return outputs