import concurrent
from openai import AzureOpenAI
import base64
import json
import boto3
import asyncio
from openai import AzureOpenAI, AsyncAzureOpenAI
import os
import base64
import yaml
from botocore.config import Config
from concurrent.futures import ThreadPoolExecutor, as_completed
import time
from pathlib import Path
import ast
import traceback
import nltk
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay, precision_score, recall_score
from pydantic import BaseModel
import pandas as pd
from openai import AsyncAzureOpenAI
from tqdm import tqdm
import asyncio
from pathlib import Path
from typing import Callable, List, Union
from typing import List, Dict, Tuple, Any
import tempfile
from pprint import pprint
import httpx
import openai
from pdf2image import convert_from_path
from datetime import date
from generator import *
from evaluator import *
from reflector import *
from utils import *
from clients.llm_client import *
from clients.llm import *
import argparse
import re
import json


def fetch_latest_txt_file(directory: str):
    path = Path(directory)
    txt_files = list(path.glob("*.txt"))
    if not txt_files:
        return None


def flatten_and_calibrate_prompt(d):
    lines = []
    if 'text_data' in d.keys():
        d = d['text_data']
    def walk(key, value, indent=0):
        prefix = "  " * indent

        # 🔹 Special handling for Schema
        if key == "Schema" and isinstance(value, dict):
            lines.append(f"{prefix}{key}:")
            schema_str = json.dumps(value, indent=2)
            for line in schema_str.splitlines():
                lines.append(f"{prefix}  {line}")
            return

        if isinstance(value, dict):
            lines.append(f"{prefix}{key}:")
            for k, v in value.items():
                walk(k, v, indent + 1)

        elif isinstance(value, list):
            lines.append(f"{prefix}{key}:")
            for item in value:
                if isinstance(item, dict):
                    for k, v in item.items():
                        walk(k, v, indent + 1)
                else:
                    lines.append(f"{prefix}  - {item}")

        else:
            lines.append(f"{prefix}{key}: {value}")

    for k, v in d.items():
        print(k)
        if k not in ['prompt_tokens', 'completion_tokens', 'total_tokens', 'cost']:
            walk(k, v)

    return "\n".join(lines)


def get_args():
    parser = argparse.ArgumentParser(description="Run prompt tuner")
    parser.add_argument(
        "--config",
        type=str,
        required=True,
        help="Path to config YAML file"
    )

    parser.add_argument(
        "--run_id",
        type=str,
        default="run1",
        help="Experiment run ID"
    )

    parser.add_argument(
        "--run_generator",
        action="store_true",
        help="Run Prompt Generator"
    )

    parser.add_argument(
        "--epoch",
        type=int,
        default=5,
        help="No of Epochs run"
    )

    parser.add_argument(
        "--run_optimiser",
        action="store_true",
        help="Run Prompt Optimiser"
    )

    parser.add_argument(
        "--snip",
        type=int,
        help="Slice of DF"
    )

    args = parser.parse_args()

    logger.info(f"Config: {args.config}")
    logger.info(f"Run ID: {args.run_id}")
    logger.info(f"Run Generator: {args.run_generator}")
    logger.info(f"Epoch: {args.epoch}")

    return args


def load_config(args):
    config = {}
    with open(args.config) as file:
        config = yaml.safe_load(file)
    config['run_id'] = args.run_id

    extraction_schema = {
        'Name': '<name data>',
        'Permanent Account Number/Permanent Account Number Card': '<pan data>',
        'DOB/Date of Incorporation/Formation': '<date data>',
        'Signature ( If Individuals)': '<sign data>'
    }
    config['extraction_schema'] = extraction_schema
    return config


def setup_run_directory(config, args):
    run_path = Path(config['results']['results_path']) / args.run_id
    run_path.mkdir(parents=True, exist_ok=True)
    return run_path


def setup_logger(run_path):
    return get_logger(os.path.join(run_path, "training.log"))


def load_annotations(config):
    annotations_data = pd.read_csv(config['document_metadata']['annotation_path'])
    annotations_data = annotations_data.drop_duplicates(subset=['file_path'], keep='last')
    return annotations_data


def setup_prompt_folders(config, args):
    cot_folder = Path(config['generator']['cot_folder']) / args.run_id
    prompt_folder = Path(config['generator']['prompt_folder']) / args.run_id

    cot_folder.mkdir(parents=True, exist_ok=True)
    prompt_folder.mkdir(parents=True, exist_ok=True)

    return cot_folder, prompt_folder


def initialize_components(config):
    generator = Generator(config)
    evaluator = Evaluator(config)
    reflector = Reflector(config)
    return generator, evaluator, reflector


def run_prompt_generation(
    args,
    generator,
    annotation_data_generation,
    label_columns,
    file_key,
    cot_folder,
    prompt_folder,
    generator_model,
    logger
):
    if not args.run_generator:
        return

    logger.info("Starting Prompt Generation")

    for idx, row in tqdm(annotation_data_generation.iterrows(), total=len(annotation_data_generation), desc="Generating Prompts"):
        try:
            if os.path.exists(row[file_key]):
                results_text, text_bbox, image = run_ocr_pipeline_file(row, file_key)

                prompt_cot = generator.per_example_prompting(
                    row,
                    label_columns,
                    text_bbox,
                    image,
                    generator_model,
                    generator.generation_prompt
                )

                cot_filename = (
                    f"key_def_{Path(os.path.basename(row[file_key])).stem}_"
                    f"{generator_model['model_name']}.json"
                )
                with open(os.path.join(cot_folder, cot_filename), "w") as f:
                    json.dump(prompt_cot, f, indent=4)

                prompt = generator.prompt_construction(prompt_cot, row[label_columns])
                
                prompt_filename = (
                    f"key_def_{Path(os.path.basename(row[file_key])).stem}_"
                    f"{generator_model['model_name']}.txt"
                )
                
                with open(os.path.join(prompt_folder, prompt_filename), "w") as file:
                    file.write(prompt)
            else:
                print("File does not exist")
        except Exception as e:
            print(f"Error occurred in Prompt Generation: {e}")
            traceback.print_exc()
    logger.info("Prompts Generation Completed!")


def run_optimizer_loop(
    args,
    config,
    evaluator,
    reflector,
    annotations_data,
    model_choices,
    file_key,
    logger
):
    if not args.run_optimiser:
        return

    prompt = read_text_file(config['evaluator']['start_prompt'])
    prompt_map = []
    accuracy_map = []

    for epoch in range(args.epoch):
        logger.info(f"===== Epoch {epoch} =====")

        base_path = os.path.join(config['results']['results_path'], args.run_id)
        eval_path = os.path.join(base_path, f"eval_results_{epoch}.csv")
        results_path = os.path.join(base_path, f"results_df_{epoch}.csv")
        prompt_path = os.path.join(base_path, f"prompt_{epoch}.txt")
        accuracy_path = os.path.join(base_path, f"accuracy_metrics_{epoch}.csv")

        prompt_map.append(prompt)

        predictions = per_example_prompting_extraction(
            config,
            model_choices[3],
            config['extraction']['system_msg'],
            config['extraction_schema'],
            prompt,
            annotations_data
        )

        pred_df = pd.DataFrame(predictions)
        pred_df['llm_output'] = pred_df['llm_output'].apply(
            lambda x: ast.literal_eval(x) if isinstance(x, str) else x
        )
        expanded = pd.json_normalize(pred_df['llm_output'])
        pred_df = pd.concat([pred_df.drop(columns=['llm_output']), expanded], axis=1)

        pred_df.to_csv(os.path.join(base_path, f"pred_{epoch}.csv"), index=False)
        logger.info(f"Saved predictions to pred_{epoch}.csv")
        logger.info(f"Predictions Shape: {pred_df.shape}")

        accuracy_scores = evaluator.heuristic_evaluate_accuracy(predictions, annotations_data)
        heur_acc = accuracy_scores["heuristic_doc_ext_accuracy"].eq(1).mean() * 100

        accuracy_map.append(heur_acc)
        max_value_acc = max(accuracy_map)
        max_index_acc = accuracy_map.index(max_value_acc)

        best_prompt = prompt_map[max_index_acc]

        logger.info(f"Heuristic Doc Accuracy: {heur_acc:.2f}%")

        if heur_acc < max_value_acc:
            prompt = best_prompt
            epoch = epoch + 1

        accuracy_scores.to_csv(accuracy_path, index=False)
        logger.info("Saved accuracy metrics")

        eval_results = evaluator.run_evaluator(predictions, annotations_data)
        new_eval_df = evaluator.convert_eval_to_df(eval_results)

        results_df = pd.merge(new_eval_df, pred_df, on='filename', how='left')
        results_df = pd.merge(
            results_df,
            annotations_data,
            left_on='filename',
            right_on=file_key,
            how='left'
        )
        results_df.to_csv(results_path, index=False)

        if new_eval_df.empty:
            logger.info("Prompt tunedx")
            break

        mismatch_cols = [col for col in new_eval_df.columns if 'mismatch__' in col]
        new_eval_df["llm_doc_ext_accuracy"] = (
            ~new_eval_df[mismatch_cols].isin(["OCR_issue", "extraction_issue"]).any(axis=1)
        ).astype(int)

        new_eval_df.to_csv(eval_path, index=False)
        logger.info(f"Saved evaluator results: {eval_path}")

        new_prompt = reflector.run_reflector_single_call(eval_results, prompt)
        logger.info(f"New prompt: \n {new_prompt}")

        prompt = flatten_and_calibrate_prompt(new_prompt)

        with open(prompt_path, "w") as f:
            f.write(prompt)

        logger.info(
            f"Saved improved prompt: {prompt_path}, "
            f"Heuristic Doc Accuracy: {heur_acc:.2f}%"
        )


def main():
    print("Running Prompt Tuner")
    args = get_args()

    config = load_config(args)
    run_path = setup_run_directory(config, args)
    logger = setup_logger(run_path)

    model_choices = config.get("model_choices")
    annotations_data = load_annotations(config)[:args.snip]
    annotations_data = annotations_data.dropna()
    annotation_data_generation = annotations_data.copy()

    label_columns = config['document_metadata']['label_columns']
    file_key = config['document_metadata']['file_key']

    cot_folder, prompt_folder = setup_prompt_folders(config, args)

    logger.info(f"Annotation Shape: {annotations_data.shape}")
    logger.info(f"Annotation Columns: {list(annotations_data.columns)}")
    logger.info(f"Label Columns: {label_columns}")

    generator, evaluator, reflector = initialize_components(config)

    generator_model = model_choices[config['generator']['model_choice']]
    logger.info(f"Generator Model: {generator_model}")
    logger.info(f"Evaluator Model: {evaluator.model}")
    logger.info(f"Reflector Model: {reflector.model}")

    run_prompt_generation(
        args,
        generator,
        annotation_data_generation,
        label_columns,
        file_key,
        cot_folder,
        prompt_folder,
        generator_model,
        logger
    )

    run_optimizer_loop(
        args,
        config,
        evaluator,
        reflector,
        annotations_data,
        model_choices,
        file_key,
        logger
    )


if __name__ == "__main__":
    main()


# if __name__ == "__main__":
#     print("Running Prompt Tuner")
#     args = get_args()
#     eval_results = {}
#     predictions = []

#     config = {}
#     with open(args.config) as file:
#         config = yaml.safe_load(file)
#     config['run_id'] = args.run_id
#     extraction_schema = {'Name': '<name data>',
#              'Permanent Account Number/Permanent Account Number Card': '<pan data>',
#              'DOB/Date of Incorporation/Formation': '<date data>',
#              'Signature ( If Individuals)': '<sign data>'}
#     config['extraction_schema'] = extraction_schema
#     file_key = config['document_metadata']['file_key']

#     if not os.path.exists(os.path.join(config['results']['results_path'], args.run_id)):
#         os.mkdir(os.path.join(config['results']['results_path'], args.run_id))

#     logger = get_logger(os.path.join(config['results']['results_path'], args.run_id, "training.log"))

#     model_choices = config.get("model_choices")
#     annotations_data = pd.read_csv(config['document_metadata']['annotation_path'])
#     annotations_data = annotations_data.drop_duplicates(subset=['file_path'], keep='last')
#     label_columns = config['document_metadata']['label_columns']
#     cot_folder = Path(config['generator']['cot_folder']) / args.run_id
#     prompt_folder = Path(config['generator']['prompt_folder']) / args.run_id

#     cot_folder.mkdir(parents=True, exist_ok=True)
#     prompt_folder.mkdir(parents=True, exist_ok=True)

    
#     logger.info(f"Annotation Shape: {annotations_data.shape}")
#     logger.info(f"Annotation Columns: {list(annotations_data.columns)}")
#     logger.info(f"Label Columns: {label_columns}")

#     generator = Generator(config)
#     evaluator = Evaluator(config)
#     reflector = Reflector(config)

#     text_txt_path = config['document_metadata']['text_data_path']
#     text_bbox_txt_path = config['document_metadata']['text_data_bbox_path']
#     results_text = {}
#     results_text_bbox = {}
#     logger.info(f"Running generator: {args.run_generator}")
#     generator_model = model_choices[config['generator']['model_choice']]
#     annotation_data_generation = annotations_data.copy()

#     logger.info(f"Generator Model: {generator_model}")
#     logger.info(f"Evaluator Model: {evaluator.model}")
#     logger.info(f"Reflector Model: {reflector.model}")
#     # results_text, results_text_bbox = run_ocr_pipeline(annotation_data_rotated, file_key)

#     if args.run_generator:
#         logger.info("Starting Prompt Generation")
#         for idx, row in tqdm(annotation_data_generation.iterrows(), desc="Generating Prompts"):
#             try:
#                 if os.path.exists(row[file_key]):
#                     results_text, text_bbox, image = run_ocr_pipeline_file(row, file_key)
#                     prompt_cot = generator.per_example_prompting(row, label_columns,\
#                                  text_bbox, image, generator_model, generator.generation_prompt)
#                     cot_filename = f"key_def_{Path(os.path.basename(row[file_key])).stem}_{generator_model['model_name']}.json"
#                     with open(os.path.join(cot_folder, cot_filename), "w") as f:
#                         json.dump(prompt_cot, f, indent=4)

#                     prompt = generator.prompt_construction(prompt_cot, row[label_columns])
#                     prompt_filename = f"key_def_{Path(os.path.basename(row[file_key])).stem}_{generator_model['model_name']}.txt"
#                     with open(os.path.join(prompt_folder, prompt_filename), "w") as file:
#                         file.write(prompt)
#                     logger.info("Prompts Generation Completed!")
#                 else:
#                     print("File does not exist")
#             except Exception as e:
#                 print(f"Error occurred in Prompt Generation: {e}")
#                 traceback.print_exc()

#     if args.run_optimiser:
#         prompt = read_text_file(config['evaluator']['start_prompt'])
#         prompt_map = []
#         accuracy_map = []

#         for epoch in range(args.epoch):
#             logger.info(f"===== Epoch {epoch} =====")
#             eval_path = os.path.join(config['results']['results_path'], args.run_id, f"eval_results_{epoch}.csv")
#             results_path = os.path.join(config['results']['results_path'], args.run_id, f"results_df_{epoch}.csv")
#             prompt_path = os.path.join(config['results']['results_path'], args.run_id, f"prompt_{epoch}.txt")
#             accuracy_path = os.path.join(config['results']['results_path'], args.run_id, f"accuracy_metrics_{epoch}.csv")

#             # 1. Extraction
#             prompt_map.append(prompt)
#             predictions = per_example_prompting_extraction(
#                 config,
#                 model_choices[3],
#                 config['extraction']['system_msg'],
#                 config['extraction_schema'],
#                 prompt,
#                 annotations_data
#             )
#             pred_df = pd.DataFrame(predictions)
#             pred_df['llm_output'] = pred_df['llm_output'].apply(
#                 lambda x: ast.literal_eval(x) if isinstance(x, str) else x)
#             expanded = pd.json_normalize(pred_df['llm_output'])
#             pred_df = pd.concat([pred_df.drop(columns=['llm_output']), expanded], axis=1)
#             pred_df.to_csv(os.path.join(config['results']['results_path'], args.run_id, f"pred_{epoch}.csv"), index=False)
#             logger.info(f"Saved predictions to pred_{epoch}.csv")
#             logger.info(f"Predictions Shape: {pred_df.shape}")
    
#             # 2. Heuristic accuracy
#             accuracy_scores = evaluator.heuristic_evaluate_accuracy(predictions, annotation_data_rotated)
#             heur_acc = accuracy_scores["heuristic_doc_ext_accuracy"].eq(1).mean() * 100
    
#             accuracy_map.append(heur_acc)
#             max_value_acc = max(accuracy_map)
#             max_index_acc = accuracy_map.index(max_value_acc)
    
#             best_prompt = prompt_map[max_index_acc]
    
#             logger.info(f"Heuristic Doc Accuracy: {heur_acc:.2f}%")
#             if heur_acc < max_value_acc:
#                 prompt = best_prompt
#                 epoch = epoch + 1
    
#             accuracy_scores.to_csv(accuracy_path, index=False)
#             logger.info("Saved accuracy metrics")
    
#             # 3. LLM evaluator
#             eval_results = evaluator.run_evaluator(predictions, annotation_data_rotated)
#             new_eval_df = evaluator.convert_eval_to_df(eval_results)
    
#             results_df = pd.merge(new_eval_df, pred_df, on='filename', how='left')
#             results_df = pd.merge(results_df, annotation_data_rotated, left_on='filename', right_on=file_key, how='left')
    
#             results_df.to_csv(results_path, index=False)
    
#             if not new_eval_df.empty:
#                 mismatch_cols = [col for col in new_eval_df.columns if 'mismatch__' in col]
#                 new_eval_df["llm_doc_ext_accuracy"] = (
#                     ~new_eval_df[mismatch_cols].isin(["OCR_issue", "extraction_issue"]).any(axis=1)
#                 ).astype(int)
    
#                 new_eval_df.to_csv(eval_path, index=False)
#                 logger.info(f"Saved evaluator results: {eval_path}")
    
#             # 4. Reflector improves prompt
#                 new_prompt = reflector.run_reflector_single_call(eval_results, prompt)
#                 logger.info(f"New prompt: \n {new_prompt}")
#                 prompt = flatten_and_calibrate_prompt(new_prompt)
    
#                 with open(prompt_path, "w") as f:
#                     f.write(prompt)
#                 logger.info(f"Saved improved prompt: {prompt_path}, Heuristic Doc Accuracy: {heur_acc:.2f}%")
    
#             else:
#                 logger.info("Prompt tunedx")
#                 break