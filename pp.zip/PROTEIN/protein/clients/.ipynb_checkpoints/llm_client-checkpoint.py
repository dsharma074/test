import os
import time
import logging
import requests
import ssl
import openai
import httpx
from enum import Enum
from pydantic import BaseModel

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

os.environ["USE_LLM_GATEWAY"] = "true"
os.environ["LLM_GW_TOKEN_REFRESH_URL"] = "https://llm-gateway.uat-phoenix.idfcfirstbank.com/api/v1/auth/tenant/generate-token"
os.environ["LLM_GATEWAY_BASE_URL"] = "https://llm-gateway.uat-phoenix.idfcfirstbank.com/tenant"

os.environ["AZURE_GPT4V_VIA_LLMGW_URL"] = "gpt4-vision/openai/deployments/GPT4UATVision/chat/completions?api-version=2024-03-01-preview"
os.environ["AZURE_GPT4O_VIA_LLMGW_URL"] = "gpt-4o/openai/deployments/IDFC-GenAi-UATGPT4o/chat/completions?api-version=2024-08-01-preview"
os.environ["AZURE_GPT5MINI_VIA_LLMGW_URL"] = "gpt-5-mini/openai/deployments/IDFC-GenAI-gpt-5-mini-uat/chat/completions?api-version=2024-12-01-preview"
os.environ["AZURE_GPT5_VIA_LLMGW_URL"] = "gpt-5/openai/deployments/IDFC-GenAI-gpt-5-AusEAS/chat/completions?api-version=2024-12-01-preview"
os.environ["AZURE_GPT4O_MINI_PTU_VIA_LLMGW_URL"] = "gpt-4o-mini-ptu/openai/deployments/gpt-4o-mini/chat/completions?api-version=2024-03-01-preview"

os.environ["LLM_GW_TENANT"] = "docsights_ml_service"
os.environ["LLM_GW_TENANT_SECRET"] = "e1599cf2-75b9-4508-8eec-bd5e22512daf"

SSL_CERT_PATH = "/home/ec2-user/SageMaker/auto-train/prompt_tuner/IDFCBANKCA.pem"


class LLM_GW_MODEL_URL(Enum):
    AZURE_GPT_VIA_LLMGW_URL = "LLM_GATEWAY_BASE_URL"
    AZURE_GPT4O_VIA_LLMGW_URL = "AZURE_GPT4O_VIA_LLMGW_URL"
    AZURE_GPT4V_VIA_LLMGW_URL = "AZURE_GPT4V_VIA_LLMGW_URL"
    AZURE_GPT5MINI_VIA_LLMGW_URL = "AZURE_GPT5MINI_VIA_LLMGW_URL"
    AZURE_GPT5_VIA_LLMGW_URL = "AZURE_GPT5_VIA_LLMGW_URL"
    AZURE_GPT4O_MINI_PTU_VIA_LLMGW_URL = "AZURE_GPT4O_MINI_PTU_VIA_LLMGW_URL"


# === Response wrappers ===
class ResponseMessage:
    def __init__(self, content):
        self.content = content


class ResponseChoice:
    def __init__(self, content):
        self.message = ResponseMessage(content)


class ResponseUsage:
    def __init__(self, usage_dict):
        self.prompt_tokens = usage_dict.get("prompt_tokens", 0)
        self.completion_tokens = usage_dict.get("completion_tokens", 0)
        self.total_tokens = usage_dict.get("total_tokens", 0)


class ChatCompletionResponse:
    def __init__(self, content, usage_dict):
        self.choices = [ResponseChoice(content)]
        self.usage = ResponseUsage(usage_dict)


# === Token Manager ===
class TokenManager:
    def __init__(self, refresh_url: str, ssl_cert=None, token_expiry: int = 6300):
        self.refresh_url = refresh_url
        self.ssl_cert = ssl_cert
        self.token_expiry = token_expiry
        self.jwt_token = None
        self.token_expiry_time = 0

        # load from environment if present
        env_token = os.environ.get("LLM_GW_JWT_TOKEN")
        env_expiry = os.environ.get("LLM_GW_JWT_TOKEN_EXPIRY")
        if env_token and env_expiry and time.time() < float(env_expiry):
            self.jwt_token = env_token
            self.token_expiry_time = float(env_expiry)
        else:
            self.refresh_token()

    def is_token_expired(self):
        return time.time() > self.token_expiry_time

    def _update_env(self):
        os.environ["LLM_GW_JWT_TOKEN"] = self.jwt_token
        os.environ["LLM_GW_JWT_TOKEN_EXPIRY"] = str(self.token_expiry_time)

    def refresh_token(self):
        logger.info("Refreshing JWT token for LLM gateway")
        headers = {"Content-Type": "application/json"}
        payload = {
            "tenant_id": os.environ["LLM_GW_TENANT"],
            "secret": os.environ["LLM_GW_TENANT_SECRET"]
        }

        resp = requests.post(
            self.refresh_url, headers=headers, json=payload, verify=self.ssl_cert or True
        )
        resp.raise_for_status()
        data = resp.json()
        new_token = data.get("data", {}).get("token")
        if not new_token:
            raise ValueError(f"Token refresh failed: response: {data}")

        self.jwt_token = new_token
        self.token_expiry_time = time.time() + self.token_expiry
        self._update_env()
        logger.info("JWT token refreshed successfully")

    def get_token(self):
        if not self.jwt_token or self.is_token_expired():
            self.refresh_token()
        return self.jwt_token


# === LLM Client ===
class LLMClient:
    def chat_completion(self, model, messages, temperature=0, max_tokens=10000, response_format = None, reasoning="low", verbosity="low"):
        raise NotImplementedError("Subclasses must implement chat_completion")


class InHouseLLMClient(LLMClient):
    def __init__(self, deployment_name: str, ssl_cert=None):
        self.deployment_name = deployment_name
        self.ssl_cert = ssl_cert or SSL_CERT_PATH
        refresh_url = os.environ["LLM_GW_TOKEN_REFRESH_URL"]
        self.token_manager = TokenManager(refresh_url=refresh_url, ssl_cert=self.ssl_cert)

    def get_model_url(self):
        base_url = os.environ["LLM_GATEWAY_BASE_URL"]
        if self.deployment_name == "GPT4-Vision":
            url = os.environ[LLM_GW_MODEL_URL.AZURE_GPT4V_VIA_LLMGW_URL.value]
        elif self.deployment_name == "GPT5-Mini":
            url = os.environ[LLM_GW_MODEL_URL.AZURE_GPT5MINI_VIA_LLMGW_URL.value]
        elif self.deployment_name == "GPT5":
            url = os.environ[LLM_GW_MODEL_URL.AZURE_GPT5_VIA_LLMGW_URL.value]
        elif self.deployment_name == "GPT4O":
            url = os.environ[LLM_GW_MODEL_URL.AZURE_GPT4O_VIA_LLMGW_URL.value]
        elif self.deployment_name == "GPT4O-Mini-PTU":
            url = os.environ[LLM_GW_MODEL_URL.AZURE_GPT4O_MINI_PTU_VIA_LLMGW_URL.value]
        else:
            print("No such model exists.")
            url=None

        if not url:
            raise EnvironmentError(f"URL not set for deployment: {self.deployment_name}")
        return f"{base_url}/{url}"


    def chat_completion(self, model, messages, temperature=1, max_tokens=10000, response_format = None, reasoning="low", verbosity="low"):
        token = self.token_manager.get_token()
        headers = {"Authorization": f"{token}", "Content-Type": "application/json"}

        payload = (
            {"model": model, "messages": messages, "reasoning_effort": reasoning, "verbosity": verbosity}
            if "GPT5" in model
            else {"model": model, "messages": messages, "temperature": temperature, "max_tokens": max_tokens}
        )

        # if response_format:
        #     payload["response_format"]= {"type": "json_schema", "json_schema": response_format}
        # else:
        #     payload["response_format"] = {"type":"json_object"}
        resp = requests.post(self.get_model_url(), headers=headers, json=payload, verify=self.ssl_cert or True)

        if resp.status_code == 401:
            logger.warning("401 Unauthorized, refreshing token and retrying")
            token = self.token_manager.refresh_token()
            headers["Authorization"] = f"{token}"
            resp = requests.post(self.get_model_url(), headers=headers, json=payload, verify=self.ssl_cert or True)

        if resp.status_code == 429:
            logger.warning("429 Too many requests: Waiting for 5secs")
            time.sleep(5)
            resp = requests.post(self.get_model_url(), headers=headers, json=payload, verify=self.ssl_cert or True)

        resp.raise_for_status()
        data = resp.json()
        content = data.get("choices", [{}])[0].get("message", {}).get("content", "")
        usage = data.get("usage", {})
        return ChatCompletionResponse(content, usage)