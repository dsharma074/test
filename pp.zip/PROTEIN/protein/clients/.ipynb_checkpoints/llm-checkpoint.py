from clients.llm_client import InHouseLLMClient
import json
import io
import base64
from pathlib import Path
from typing import List, Tuple, Union
from pdf2image import convert_from_path
from PIL import Image
import os
import time
import traceback
import requests
import sys


llm_map = {
    "gpt-5-mini": "GPT5-Mini",
    "gpt-4o": "GPT4O",
    "gpt-4-vision": "GPT4-Vision",
    "gpt-5": "GPT5",
    "gpt4o-mini-ptu": "GPT4O-Mini-PTU"
}

def parse_json_garbage(s: str) -> dict:
    # Find first '{' or '[' safely
    
    try:
        s = s.replace('`', "")
        idx = next((i for i, c in enumerate(s) if c in "{["), None)
        # if idx is None:
        #     return {"text_data": s}  # fallback: return raw text
    
        s = s[idx:]  # slice from first JSON-like char
        return json.loads(s)
    except Exception as e:
        print(s)
        return {'text_data': s}


def build_image_parts(file_path, dpi=200):
    """
    Convert PDF/image file to page-wise bytes and base64 lists.
    Returns: (bytes_list, base64_list)
    """
    file_path = Path(file_path)
    ext = file_path.suffix.lower()
    image_bytes_list = []
    base64_list = []

    if ext == ".pdf":
        pages = convert_from_path(str(file_path), dpi=dpi)
        for page in pages:
            buf = io.BytesIO()
            page.save(buf, format="JPEG")
            b = buf.getvalue()
            image_bytes_list.append(b)
            base64_list.append(base64.b64encode(b).decode("utf-8"))

    elif ext in [".png", ".jpg", ".jpeg", ".tiff", ".bmp", ".gif"]:
        img = Image.open(file_path)
        buf = io.BytesIO()
        fmt = "JPEG"
        # fmt = "PNG" if ext == ".png" else "JPEG"
        img.save(buf, format=fmt)
        b = buf.getvalue()
        image_bytes_list.append(b)
        base64_list.append(base64.b64encode(b).decode("utf-8"))

    else:
        raise ValueError(f"Unsupported file type: {ext}")

    return [
        {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{b}"}}
        for b in base64_list
    ]

def add_images_to_message(image_list, dpi=200):
    base64_list = []
    for img1 in image_list:
        img = img1.convert("RGB")
        buf = io.BytesIO()
        fmt = "JPEG"
        # fmt = "PNG" if ext == ".png" else "JPEG"
        img.save(buf, format=fmt)
        b = buf.getvalue()
        base64_list.append(base64.b64encode(b).decode("utf-8"))
    return [
        {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{b}"}}
        for b in base64_list
    ]

# def run_chat_completion(system_prompt, user_prompt, schema, file_path, model_config):
#     model_name = llm_map.get(model_config.get("model_name", "gpt-4o"), "gpt-4o")
#     client = InHouseLLMClient(deployment_name=model_name)

#     user_content = [{"type": "text", "text": user_prompt}]
#     if file_path:
#         user_content += build_image_parts(file_path)

#     messages = [
#         {"role": "system", "content": system_prompt},
#         {"role": "user", "content": user_content}
#     ]

#     # ensure schema validity
#     schema = schema if isinstance(schema, dict) else None

#     response = client.chat_completion(
#         model=model_name,
#         messages=messages,
#         temperature=model_config.get("temperature", 0.75)
#         # response_format=schema
#     )

#     content = response.choices[0].message.content
#     usage = response.usage

#     try:
#         data = json.loads(content)
#     except json.JSONDecodeError:
#         data = {"text_data": content}

#     data.update({
#         "prompt_tokens": usage.prompt_tokens,
#         "completion_tokens": usage.completion_tokens,
#         "total_tokens": usage.total_tokens
#     })

#     return data


def costing(model_name, input_token, output_tokens):
    if model_name == 'GPT5':
        return 80*(1.25*(input_token/1000000) +  10*(output_tokens/1000000))
    elif model_name == "GPT5-Mini":
        return 80*(0.25*(input_token/1000000) +  2*(output_tokens/1000000))
    elif model_name == "GPT4O":
        return 80*(0.05*(input_token/1000000) +  0.4*(output_tokens/1000000))


def run_chat_completion_dict(
    system_prompt,
    user_prompt,
    schema,
    final_image,
    model_config,
    max_retries=3,
    retry_delay=5,
):
    model_name = llm_map.get(model_config.get("model_name", "gpt-4o"), "")
    client = InHouseLLMClient(deployment_name=model_name)

    if final_image is not None:
        messages = [
            {"role": "system", "content": system_prompt},
            {
                "role": "user",
                "content": [{"type": "text", "text": user_prompt}]
                + add_images_to_message([final_image])
            }
        ]
    else:
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": [{"type": "text", "text": user_prompt}]}
        ]

    for attempt in range(1, max_retries + 1):
        response = None
        try:
            if model_name in ("GPT5", "GPT5-Mini"):
                response = client.chat_completion(
                    model=model_name,
                    messages=messages,
                    temperature=model_config.get("temperature", 0.0),
                    reasoning=model_config.get("reasoning_effort", "minimal"),
                    response_format=schema,
                    verbosity=model_config.get("verbosity", "low"),
                )
            else:
                response = client.chat_completion(
                    model=model_name,
                    messages=messages,
                    temperature=model_config.get("temperature", 0.0),
                    response_format=schema,
                )
            # ---------- Parse content ----------
            if getattr(response, "choices", None):
                msg = getattr(response.choices[0], "message", None)
                content_raw = getattr(msg, "content", "")
                content = parse_json_garbage(content_raw)
            else:
                content = {"text_data": ""}

            usage = getattr(response, "usage", None)

            # ---------- Final data ----------
            if isinstance(content, dict):
                data = content
            else:
                data = json.loads(content)

            if usage:
                data["prompt_tokens"] = usage.prompt_tokens
                data["completion_tokens"] = usage.completion_tokens
                data["total_tokens"] = usage.total_tokens
                data["cost"] = costing(
                    model_name,
                    usage.prompt_tokens,
                    usage.completion_tokens,
                )
            return data

        except requests.exceptions.HTTPError as e:
            last_error = e
            status = getattr(e.response, "status_code", None)

            print(
                f"[Retry {attempt}/{max_retries}] "
                f"{model_name} HTTP {status}. Retrying in {retry_delay}s..."
            )
            time.sleep(retry_delay * attempt)
            continue

        except Exception as e:
            last_error = e
            print(
                f"[Retry {attempt}/{max_retries}] "
                f"{model_name} unexpected error: {e}"
            )
            time.sleep(retry_delay * attempt)
            continue

    # ---------- FINAL FAILURE FALLBACK ----------
    print(f"LLM failed after {max_retries} attempts: {last_error}")

    return {
        "text_data": "",
        "error": str(last_error),
        "model_name": model_name,
    }


def run_chat_completion_text(system_prompt, user_prompt, schema, file_path, model_config):
    model_name = llm_map.get(model_config.get("model_name", 'gpt-4o'), "")
    client = InHouseLLMClient(deployment_name=model_name)
    messages = []
    if file_path!=None:
        messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": [{"type": "text", "text": user_prompt}] + build_image_parts(file_path)}
            ]
    else:
        messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": [{"type": "text", "text": user_prompt}]}
            ]
    response = None
    if model_name == 'GPT5':
        response = client.chat_completion(
            model = model_name,
            messages = messages,
            reasoning = model_config.get("reasoning_effort", 'minimal'),
            response_format = schema,
            verbosity = model_config.get("verbosity", 'low')
        )
    else:
        response = client.chat_completion(
            model = model_name,
            messages = messages,
            temperature = model_config.get("temperature", 0.75),
            response_format = schema
        )
    content = response.choices[0].message.content
    content = parse_json_garbage(content)
    usage = response.usage

    if isinstance(content, dict):
        data = content
    else:
        try:
            data = json.loads(content)
            data["cost"] =  costing(model_name, usage.prompt_tokens, usage.completion_tokens)
            data["prompt_tokens"], data["completion_tokens"], data["total_tokens"] = usage.prompt_tokens, usage.completion_tokens, usage.total_tokens
        except (json.JSONDecodeError, TypeError):
            data = {"text_data": content}
    
    return data